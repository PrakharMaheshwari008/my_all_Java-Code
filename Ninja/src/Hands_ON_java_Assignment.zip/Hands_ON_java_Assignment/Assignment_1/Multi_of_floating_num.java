package Hands_ON_java_Assignment.Assignment_1;

import java.util.Scanner;

public class Multi_of_floating_num {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        float num1 = sc.nextFloat();
        float num2 = sc.nextFloat();
        System.out.println("Multiple of two Number : "+num1 * num2);
    }
}
