package Hands_ON_java_Assignment.Assignment_1;

import java.util.Scanner;

public class Users_integer {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        int num = sc.nextInt();
        System.out.println(num);
    }
}
