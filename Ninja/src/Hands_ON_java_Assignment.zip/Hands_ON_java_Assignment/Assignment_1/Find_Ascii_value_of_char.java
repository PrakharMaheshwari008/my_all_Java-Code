package Hands_ON_java_Assignment.Assignment_1;

import java.util.Scanner;

public class Find_Ascii_value_of_char {
    public static void main(String[] args) {

        Scanner sc =new Scanner(System.in);
        char ch = sc.next().charAt(0);
        System.out.println((int)ch);

    }
}

